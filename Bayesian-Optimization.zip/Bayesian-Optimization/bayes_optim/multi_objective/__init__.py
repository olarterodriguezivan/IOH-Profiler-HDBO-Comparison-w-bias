from .analytic import EHVI

__all__ = ["EHVI"]
